## Benchmark 对比报告
模型: /root/sj-tmp/models/Qwen3.5-2B-Base | 样本数: 36 | 异常: 0

### 性能对比（平均值）

| 指标 | native_tool_calling |
|---|---|
| 总耗时(ms) | 46174.1 |
| LLM 时间(ms) | 46158.7 |
| 工具时间(ms) | 2.7 |
| 路由时间(ms) | 0 |
| 框架开销(ms) | 12.7 |
| 迭代次数 | 7.3 |
| Token 用量 | 29105.9 |

### 可靠性（pass^k：k 次试验全部成功）

| 指标 | native_tool_calling |
|---|---|
| pass^1 | 0% |
| pass^2 | 0% |
| pass^3 | 0% |

### 准确性对比

| 指标 | native_tool_calling |
|---|---|
| 正常结束率(FINISH) | 42% |
| 严格成功率 | 0% |
| 工具调用准确率 | 8% |
| 参数准确率 | 32% |
| 指代解析准确率 | 24% |
| 阻塞终止语义准确率 | n/a |
| 假完成率 | 25% |
| 平均解析失败 | 0 |
| 平均工具失败 | 1.4 |

### 代价（按成功次数归一化）

| 指标 | native_tool_calling |
|---|---|
| Token / 成功 | n/a |
| 工具调用 / 成功 | n/a |
| 耗时(ms) / 成功 | n/a |
| 迭代数中位·成功 | n/a |
| 迭代数中位·失败 | 8 |

失败形态：

| 指标 | native_tool_calling |
|---|---|
| 撞迭代上限 | 21 |
| 声称完成但错 | 15 |
| 异常终止 | 0 |

### 任务难度分档（跨 Agent 合并成功率）

| 档位 | 成功率 | 任务数 | 用途 |
|---|---|---|---|
| floor | < 20% | 12 | 评测下限；GRPO 无梯度 |
| middle | 20~80% | 0 | **GRPO 训练集**；奖励方差最大 |
| ceiling | > 80% | 0 | 评测上限；GRPO 无梯度 |

### 按任务对比

| 任务 | 样本 | 平均耗时(ms) | 正常结束率 | 严格成功率 | 工具准确率 |
|---|---|---|---|---|---|
| challenge_sealed_test_01_A | 3 | 50459 | 0% | 0% | 0% |
| challenge_sealed_test_02_A | 3 | 51419.3 | 0% | 0% | 0% |
| challenge_sealed_test_03_B | 3 | 43305 | 67% | 0% | 0% |
| challenge_sealed_test_04_B | 3 | 39153.7 | 0% | 0% | 0% |
| challenge_sealed_test_05_C | 3 | 35845.3 | 100% | 0% | 0% |
| challenge_sealed_test_06_C | 3 | 57254.7 | 0% | 0% | 0% |
| challenge_sealed_test_07_C | 3 | 66833 | 0% | 0% | 0% |
| challenge_sealed_test_08_D | 3 | 38625.7 | 33% | 0% | 0% |
| challenge_sealed_test_09_D | 3 | 49582.3 | 0% | 0% | 0% |
| challenge_sealed_test_10_E | 3 | 54218.3 | 100% | 0% | 0% |
| challenge_sealed_test_11_E | 3 | 35845.3 | 100% | 0% | 100% |
| challenge_sealed_test_12_F | 3 | 31547.3 | 100% | 0% | 0% |